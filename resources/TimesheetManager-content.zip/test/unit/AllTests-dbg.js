sap.ui.define([
	"cap/trello/TimesheetManager/test/unit/controller/Boards.controller"
], function () {
	"use strict";
});
